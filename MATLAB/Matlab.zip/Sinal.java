import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

import java.util.ArrayList;

public class Sinal {

    public static int hex2dec(String hexadecimal) {
        int valor = 0;
        int posicaoCaractere = - 1;
        char[] hexa = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

        // soma ao valor final o dígito binário da posição * 16 elevado ao contador da posição (começa em 0)
        for (int i = hexadecimal.length(); i > 0; i--) {
            posicaoCaractere = Arrays.binarySearch(hexa, hexadecimal.charAt(i - 1));
            valor += posicaoCaractere * Math.pow(16, (hexadecimal.length() - i));
        }

        return valor;
    }

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);

//        String nome = ler.nextLine();
        String nome = "teste_20180524.txt";
        String sinal = ""; // Guarda o sinal completo

        ArrayList<Integer> index_hb_ch2 = new ArrayList<Integer>();
        ArrayList<Integer> index_lb_ch2 = new ArrayList<Integer>();
        ArrayList<Integer> ECG = new ArrayList<Integer>();

        int hbnum, lbnum;

        try {
            FileReader arq = new FileReader(nome);
            BufferedReader lerArq = new BufferedReader(arq);

            String linha = lerArq.readLine();
            while (linha != null) {
                if (linha.length() == 1)
                    linha = '0' + linha;
                sinal = sinal + linha;

                linha = lerArq.readLine(); // lê da segunda até a última linha
            }

            arq.close();
        } catch (IOException e) {
            System.err.printf("Erro na abertura do arquivo: %s.\n",
                    e.getMessage());
        }

        int jj = 0;
        int find_sync = 0;
        String sync0, sync1;

//         Procura o A5 5A
        while (find_sync == 0) {
            sync0 = ("" + sinal.charAt(jj) + sinal.charAt(jj + 1));
            sync1 = ("" + sinal.charAt(jj + 2) + sinal.charAt(jj + 3));

            if (sync0.equals("A5") && sync1.equals("5A")) {
                find_sync = 1;
            } else {
                jj++;
            }
        }
//        System.out.println(sinal.charAt(jj) + "" + sinal.charAt(jj + 1));
        for (int index = jj + 9; index < sinal.length(); index += 13) {
            index_hb_ch2.add(index);
            index_lb_ch2.add(index + 1);
//            System.out.println(index_hb_ch2.get(index));
        }

        for (int kk = 0; kk < index_hb_ch2.size(); kk++) {
            hbnum = hex2dec(sinal.charAt(index_hb_ch2.get(kk)) + "" + sinal.charAt(index_hb_ch2.get(kk) + 1));
            lbnum = hex2dec(sinal.charAt(index_lb_ch2.get(kk)) + "" + sinal.charAt(index_lb_ch2.get(kk) + 1));
            ECG.add((hbnum << 8) + lbnum);
            System.out.println(hbnum);
        }
        try {
            File arquivo2 = new File("teste_20180524_montado.txt");
            arquivo2.createNewFile();
            FileWriter fileW = new FileWriter(arquivo2);//arquivo para escrita
            BufferedWriter buffW = new BufferedWriter(fileW);
            for (int dado : ECG) {
                buffW.write(dado + " ");
            }
            buffW.close();
        } catch (IOException io) {
            System.out.println(io.getStackTrace());
        }
    }
}
