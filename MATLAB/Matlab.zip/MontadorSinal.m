clear all;
fid=fopen('20180522_ECG_copy_test.txt','r');
aa=fscanf(fid,'%c\n');

jj=1;
find_sync = 0;

% Procura o A5, 5A
while find_sync == 0
    
if sum(aa(jj:jj+1) == 'A5') == 2 && sum(aa(jj+2:jj+3) == '5A') == 2
find_sync = 1;
else jj = jj+1;
end

end

% Guarda todos os numeros  jj+12 < tamanho_sinal a cada 34 passos
index_hb_ch2 = jj+12:34:length(aa);
index_lb_ch2 = jj+14:34:length(aa);

for kk = 1:length(index_hb_ch2)
    hbnum = hex2dec([aa(index_hb_ch2(kk)) aa(index_hb_ch2(kk)+1)]);
    lbnum = hex2dec([aa(index_lb_ch2(kk)) aa(index_lb_ch2(kk)+1)]);
    ECG(kk) = bitshift(hbnum,8) + lbnum;
end


fclose(fid);
figure;
plot(ECG);