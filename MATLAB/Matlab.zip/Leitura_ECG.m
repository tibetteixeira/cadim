clear all;
fid=fopen('teste_20180524_montado_t2.txt','r');
aa=fscanf(fid,'%d');

fclose(fid);
figure;
plot(aa);